/**
 * 
 */
package com.quoioln.springmvc.controller;

/**
 * @author quoioln
 *
 */
public class EmployeeController {

}
