-- insert into department table 
insert into department(name, delete_flag) values('DC1', false);
insert into department(name, delete_flag) values('DC2', false);
insert into department(name, delete_flag) values('DC3', false);
insert into department(name, delete_flag) values('DC4', false);
insert into department(name, delete_flag) values('DC5', false);
insert into department(name, delete_flag) values('DC6', false);
insert into department(name, delete_flag) values('DC7', false);
insert into department(name, delete_flag) values('DC8', false);
insert into department(name, delete_flag) values('DC9', false);
insert into department(name, delete_flag) values('DC10', false);
insert into department(name, delete_flag) values('DC11', false);
insert into department(name, delete_flag) values('DC12', false);


-- insert into employee table
insert into employee(full_name, email, gender, department_id, delete_flag)
	values('Vo Phu Quoi', 'quoipro94@gmail.com', 1, 12, false);
insert into employee(full_name, email, gender, department_id, delete_flag)
	values('Nguyen van A', 'quoipro94@gmail.com', 1, 12, false);
insert into employee(full_name, email, gender, department_id, delete_flag)
	values('Nguyen van B', 'quoipro94@gmail.com', 1, 12, false);
insert into employee(full_name, email, gender, department_id, delete_flag)
	values('Nguyen van C', 'quoipro94@gmail.com', 1, 12, false);
